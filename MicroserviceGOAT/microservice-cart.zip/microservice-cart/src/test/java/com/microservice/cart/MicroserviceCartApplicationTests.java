package com.microservice.cart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
